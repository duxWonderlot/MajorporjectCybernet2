Things need to be made for the predifined city 

Corp builings
1)(Military grade weapons) buildings 4 varients
2)(Police department say "ourcityname".P.D) buildings 4 varients (arccording to each level of the city as we discussed)
3)Bodymods Shopping centers no count can be any number
4)Ripper doc(the name can be changes accrodingly)  each layer of the city should have atleast two
  1)old hosipitals with tech induced in it
5)Hover car ShowRoom 3 variants
6)Rocket Corp(like NASA center)
7)dungeons varients buidings look something like (research:Dredd,Megacities,etc)
8) model Ads using 3d text tool and planes in maya , mode; statues(sci fi statues (holograms))(you just need to model the structure then will be converted to Vfx and Shaders)
9)One Primary and Scondary rifle with different Mods for each weapon, Sci fi Katana varients
10)old buidings for slums in the city
Common 
Connecting roads for each buildings can be of any shape but need to be walkable 
every building should have japanese look to it (please research on Japanse,Tokyo,China buildings for more ideas)
before modelling keep in mind to make buidings modular, if (in case any build does not fit in modular look can be ignored for making it normal model)



